<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    $app->get('/login/[{sucesso}]', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/login/' route");

        // Render index view
        return $container->get('renderer')->render($response, 'index2.phtml', $args);
    });

    $app->post('/login/', function (Request $request, Response $response, array $args) use ($container) {
        // Sample log message
        $container->get('logger')->info("Slim-Skeleton '/login/' route");

        $conexao = $container->get('pdo');

        $params = $request->getParsedBody();

        $resultSet = $conexao->query('SELECT * FROM cadastro 
                                      WHERE email = "' . $params['email'] . '" 
                                            AND senha = "' . md5($params['senha']) . '"')->fetchAll();

        if (count($resultSet) == 1) {

            $_SESSION['login']['ehLogado'] = true;
            $_SESSION['login']['idcadastro'] = $resultSet[0]['idcadastro'];
            $_SESSION['login']['email'] = $resultSet[0]['email'];
            
            return $response->withRedirect('/perfil/');
        } else {
            $_SESSION['login']['ehLogado'] = false;
            
            return $response->withRedirect('/perfil/');
        }

     
      
    });
};
